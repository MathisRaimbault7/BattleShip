﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet_CSharp_BattleShip
{
    class AI
    {
        int numberOfShipAliveAI = 5;
        int torpedoAILife = 2;
        int submarine1AILife = 3;
        int submarine2AILife = 3;
        int cruiserAILife = 4;
        int aircraftAILife = 10;
        public AI(int numberOfShipAliveAI, int torpedoAILife, int submarine1AILife, int submarine2AILife, int cruiserAILife, int aircraftAILife)
        {
            this.numberOfShipAliveAI = numberOfShipAliveAI;
            this.torpedoAILife = torpedoAILife;
            this.submarine1AILife = submarine1AILife;
            this.submarine2AILife = submarine2AILife;
            this.cruiserAILife = cruiserAILife;
            this.aircraftAILife = aircraftAILife;
        }
        public static int[] Position_Of_AI_Ship(int[] position, bool position_question, string type, int ship_length, string[,] grid)//Give the random position of AI's ship
        {
            Random number = new Random();
            bool start_game = true;
            while (position_question == false)
            {
                position[0] = number.Next(1, 11);
                position[1] = number.Next(1, 11);
                position[2] = number.Next(1, 11);
                position[3] = number.Next(1, 11);
                position_question = Placement.Verification_Enter_Coordinate_User(position, ship_length, grid, start_game);
            }
            return position;
        }
        public static int[] Position_Of_Area_Touched_By_AI(string[,] grid, int ship_length)//Give the position bombed by AI
        {
            bool position_question = false;
            Random number = new Random();
            int[] position = new int[2] { 0, 0 };
            while (position_question == false)
            {
                bool start_game = false;
                position[0] = number.Next(1, 11);
                position[1] = number.Next(1, 11);
                position_question = Placement.Verification_Enter_Coordinate_User(position, ship_length, grid, start_game);
                if (grid[position[0], position[1]] == "B")
                {
                    position_question = false;
                }
            }
            return position;
        }
        public static string[,] Touched_Area_By_AI(string[,] grid, int[] position)
        {
            grid[position[0], position[1]] = "B";
            return grid;
        }
        public static string Ship_Touched_Or_Not_By_AI(string[,] grid, int[] position)
        {
            string ship = "";
            if (grid[position[0], position[1]] != "B" && grid[position[0], position[1]] != "E")
            {
                ship = grid[position[0], position[1]];
            }
            return ship;
        }
        public int Number_Of_Ship_Alive_AI()
        {
            return numberOfShipAliveAI;
        }
        public int Torpedo_AI_Life()
        {
            return torpedoAILife;
        }
        public int Submarine1_AI_Life()
        {
            return submarine1AILife;
        }
        public int Submarine2_AI_Life()
        {
            return submarine2AILife;
        }
        public int Cruiser_AI_Life()
        {
            return cruiserAILife;
        }
        public int Aicraft_AI_Life()
        {
            return aircraftAILife;
        }
        public static int[] Position_Of_Area_Touched_By_AI_Brain(string[,] grid, int ship_length, int[] position)//Function which return the position choosed by AI by the classic strategy technic
        {
            bool position_question = false;
            Random number = new Random();
            int choice = 0;
            int[] position_Try = new int[2];
            while (position_question == false)
            {
                bool start_game = false;
                int x;
                int y;
                if (position[0] == 1 && position[1] == 1)
                {
                    choice = number.Next(0, 2);
                    if (choice == 0)
                    {
                        x = 0;
                        y = number.Next(0, 5);
                    }
                    else
                    {
                        x = number.Next(0, 5);
                        y = 0;
                    }
                }
                else if (position[0] == 1 && position[1] == grid.GetLength(1) - 1)
                {
                    choice = number.Next(0, 2);
                    if (choice == 0)
                    {
                        x = 0;
                        y = number.Next(-4, 5);
                    }
                    else
                    {
                        x = number.Next(-4, 5);
                        y = 0;
                    }
                }
                else if (position[0] == grid.GetLength(0) - 1 && position[1] == grid.GetLength(1) - 1)
                {
                    choice = number.Next(0, 2);
                    if (choice == 0)
                    {
                        x = 0;
                        y = number.Next(-4, 0);
                    }
                    else
                    {
                        x = number.Next(-4, 0);
                        y = 0;
                    }
                }
                else if (position[0] == grid.GetLength(0) - 1 && position[1] == 1)
                {
                    choice = number.Next(0, 2);
                    if (choice == 0)
                    {
                        x = 0;
                        y = number.Next(1, 5);
                    }
                    else
                    {
                        x = number.Next(-4, 0);
                        y = 0;
                    }
                }
                else if (position[0] == 1)
                {
                    choice = number.Next(0, 2);
                    if (choice == 0)
                    {
                        x = 0;
                        y = number.Next(-4, 5);
                    }
                    else
                    {
                        x = number.Next(1, 5);
                        y = 0;
                    }
                }
                else if (position[0] == grid.GetLength(0) - 1)
                {
                    choice = number.Next(0, 2);
                    if (choice == 0)
                    {
                        x = 0;
                        y = number.Next(-4, 5);
                    }
                    else
                    {
                        x = number.Next(-4, 0);
                        y = 0;
                    }
                }
                else if (position[1] == 1)
                {
                    choice = number.Next(0, 2);
                    if (choice == 0)
                    {
                        x = 0;
                        y = number.Next(1, 5);
                    }
                    else
                    {
                        x = number.Next(-4, 5);
                        y = 0;
                    }
                }
                else if (position[1] == grid.GetLength(1) - 1)
                {
                    choice = number.Next(0, 2);
                    if (choice == 0)
                    {
                        x = 0;
                        y = number.Next(-4, 0);
                    }
                    else
                    {
                        x = number.Next(-4, 5);
                        y = 0;
                    }
                }
                else
                {
                    choice = number.Next(0, 2);
                    if (choice == 0)
                    {
                        x = 0;
                        y = number.Next(-4, 5);
                    }
                    else
                    {
                        x = number.Next(-4, 5);
                        y = 0;
                    }
                }
                position_Try[1] = position[1] + y;
                position_Try[0] = position[0] + x;
                if (position_Try[0] <= 0 || position_Try[0] >= grid.GetLength(0) || position_Try[1] <= 0 || position_Try[1] >= grid.GetLength(1))
                {
                    position_question = false;
                }
                else
                {
                    position_question = Placement.Verification_Enter_Coordinate_User(position_Try, ship_length, grid, start_game);
                    if (grid[position_Try[0], position_Try[1]] == "B")
                    {
                        position_question = false;
                    }
                }

            }
            position[0] = position_Try[0];
            position[1] = position_Try[1];
            return position;
        }

        public static int[] Position_Of_Area_Touched_By_AI_Smart(string[,] grid, int ship_length) //Function which return the position choosed by AI randomly
        {
            bool position_question = false;
            int[] position = new int[2] { 0, 0 };
            int[,] grid_Smart = Game_Grid.Construction_Grid_Smart();
            Random number = new Random();
            bool find = false;
            int counter = 1;
            int counter2 = 1;
            while (position_question == false)
            {
                bool start_game = false;
                while (find == false)
                {
                    if (grid_Smart[counter, counter2] == 1)
                    {
                        position[0] = counter;
                        position[1] = counter2;
                        grid_Smart[counter, counter2] = 0;
                        find = true;
                    }
                    if (Game_Grid.Verification_Smart_Grid_Empty(grid_Smart) == true)
                    {
                        position[0] = number.Next(1, 11);
                        position[1] = number.Next(1, 11);
                        find = true;
                    }
                    //counter2 = number.Next(1, 11);
                    //counter = number.Next(1, 11);
                    
                    counter2++;
                    if (counter2 > 10)
                    {
                        counter++;
                        counter2 = 1;
                    }
                    if (counter > 10)
                    {
                        counter = 1;
                        counter2 = 1;
                    }
                    

                }
                position_question = Placement.Verification_Enter_Coordinate_User(position, ship_length, grid, start_game);
                if (grid[position[0], position[1]] == "B")
                {
                    position_question = false;
                }
                find = false;
            }
            return position;
        }
        public static int[] Position_Of_Area_Touched_By_AI_Big_Brain(string[,] grid, int ship_length, int[] position, int sens, int sensDirection, bool goodWay)  //Function which return the position choosed by AI with his big brain which track player's ship
        {
            bool position_question = false;
            int[] position_Try = new int[2];
            bool start_game = false;
            int x = 0;
            int y = 0;
            int counter = 0;
            int firstTime = 0;
            int stop = 0;
            int indexer = 1;
            int PlanB = 0;
            while (position_question == false)
            {
                if (goodWay == false && PlanB == 0)
                {
                    if (counter == 0)
                    {
                        x = 0;
                        y = -1;
                    }
                    else if (counter == 1)
                    {
                        x = -1;
                        y = 0;
                    }
                    else if (counter == 2)
                    {
                        x = 1;
                        y = 0;
                    }
                    else
                    {
                        x = 0;
                        y = 1;
                        PlanB = 1;
                        counter = -1;
                    }
                }
                else if (goodWay == false && PlanB == 1)
                {
                    if (counter == 0)
                    {
                        x = 0;
                        y = -2;
                    }
                    else if (counter == 1)
                    {
                        x = -2;
                        y = 0;
                    }
                    else if (counter == 2)
                    {
                        x = 2;
                        y = 0;
                    }
                    else
                    {
                        x = 0;
                        y = 2;
                        PlanB = 2;
                        counter = -1;
                    }
                }
                else if (goodWay == false && PlanB == 2)
                {
                    if (counter == 0)
                    {
                        x = 0;
                        y = -3;
                    }
                    else if (counter == 1)
                    {
                        x = -3;
                        y = 0;
                    }
                    else if (counter == 2)
                    {
                        x = 3;
                        y = 0;
                    }
                    else
                    {
                        x = 0;
                        y = 3;
                    }
                }
                else
                {
                    x = sens;
                    y = sensDirection;
                    if (firstTime == 0)
                    {
                        if (sens == 0)
                        {
                            y = sensDirection - indexer;
                        }
                        else
                        {
                            x = sens - indexer;
                        }
                    }
                    else if (firstTime > 1)
                    {
                        if (sens == 0)
                        {
                            y = sensDirection + indexer;
                        }
                        else
                        {
                            x = sens + indexer;
                        }
                        firstTime = -1;
                    }
                }
                position_Try[1] = position[1] + y;
                position_Try[0] = position[0] + x;
                if (position_Try[0] <= 0 || position_Try[0] >= grid.GetLength(0) || position_Try[1] <= 0 || position_Try[1] >= grid.GetLength(1))
                {
                    position_question = false;
                }
                else
                {
                    position_question = Placement.Verification_Enter_Coordinate_User(position_Try, ship_length, grid, start_game);
                    if (grid[position_Try[0], position_Try[1]] == "B")
                    {
                        position_question = false;
                    }
                }
                counter++;
                firstTime++;
                indexer++;
                if (stop == 1)
                {
                    break;
                }
            }
            position[0] = position_Try[0];
            position[1] = position_Try[1];
            return position;
        }
    }
}
