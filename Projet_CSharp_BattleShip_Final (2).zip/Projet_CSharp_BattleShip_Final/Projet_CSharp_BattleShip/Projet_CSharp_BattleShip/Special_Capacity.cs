﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet_CSharp_BattleShip
{
    class Special_Capacity
    {
        public static int Storm_Round(int storm2, int storm3, int vision, int cruiserBurst, int oneShot, int tornado, int volcano)
        {
            Random number = new Random();
            int answer = number.Next(3, 10);
            while (answer == storm2 || answer == storm2 - 1 || answer == storm2 + 1 || answer == storm3 - 1 || answer == storm3 + 1 || answer == storm3 || answer == vision || answer == cruiserBurst || answer == oneShot || answer == tornado || answer == volcano)
            {
                answer = number.Next(3, 10);
            }
            return answer;
        }
        public static int Storm2_Round(int storm, int storm3, int vision, int cruiserBurst, int oneShot, int tornado, int volcano)
        {
            Random number = new Random();
            int answer = number.Next(10, 20);
            while (answer == storm + 1 || answer == storm3 + 1 || answer == vision || answer == cruiserBurst || answer == oneShot || answer == tornado || answer == volcano)
            {
                answer = number.Next(10, 20);
            }
            return answer;
        }
        public static int Storm3_Round(int storm, int storm2, int vision, int cruiserBurst, int oneShot, int tornado, int volcano)
        {
            Random number = new Random();
            int answer = number.Next(20, 35);
            while (answer == storm2 + 1 || answer == vision || answer == cruiserBurst || answer == oneShot || answer == tornado || answer == volcano)
            {
                answer = number.Next(20, 35);
            }
            return answer;
        }
        public static int Vision_Round(int storm, int storm2, int storm3, int cruiserBurst, int oneShot, int tornado, int volcano)
        {
            Random number = new Random();
            int answer = number.Next(3, 15);
            while (answer == storm || answer == storm + 1 || answer == storm - 1 || answer == storm2 || answer == storm2 - 1 || answer == storm2 + 1 || answer == storm3 || answer == storm3 - 1 || answer == storm3 + 1 || answer == cruiserBurst || answer == oneShot || answer == tornado || answer == volcano)
            {
                answer = number.Next(3, 15);
            }
            return answer;
        }
        public static int Cruiser_Burst_Round(int storm, int storm2, int storm3, int vision, int oneShot, int tornado, int volcano)
        {
            Random number = new Random();
            int answer = number.Next(3, 35);
            while (answer == storm || answer == storm + 1 || answer == storm - 1 || answer == storm2 || answer == storm2 - 1 || answer == storm2 + 1 || answer == storm3 || answer == storm3 - 1 || answer == storm3 + 1 || answer == vision || answer == oneShot || answer == tornado || answer == volcano)
            {
                answer = number.Next(3, 35);
            }
            return answer;
        }

        public static int One_Shot_Round(int storm, int storm2, int storm3, int vision, int cruiserBurst, int tornado, int volcano)
        {
            Random number = new Random();
            int answer = number.Next(15, 40);
            while (answer == storm || answer == storm + 1 || answer == storm - 1 || answer == storm2 || answer == storm2 - 1 || answer == storm2 + 1 || answer == storm3 || answer == storm3 - 1 || answer == storm3 + 1 || answer == vision || answer == cruiserBurst || answer == tornado || answer == volcano)
            {
                answer = number.Next(15, 40);
            }
            return answer;
        }
        public static int Volcano_Round(int storm, int storm2, int storm3, int vision, int cruiserBurst, int tornado, int oneShot)
        {
            Random number = new Random();
            int answer = number.Next(10, 25);
            while (answer == storm || answer == storm + 1 || answer == storm - 1 || answer == storm2 || answer == storm2 - 1 || answer == storm2 + 1 || answer == storm3 || answer == storm3 - 1 || answer == storm3 + 1 || answer == vision || answer == cruiserBurst || answer == tornado || answer == oneShot)
            {
                answer = number.Next(10, 25);
            }   
            return answer;
        }
        public static int Resurrection_Round(int storm, int storm2, int storm3, int vision, int cruiserBurst, int volcano, int oneShot)
        {
            Random number = new Random();
            int answer = number.Next(30, 50);
            while (answer == storm || answer == storm + 1 || answer == storm - 1 || answer == storm2 || answer == storm2 - 1 || answer == storm2 + 1 || answer == storm3 || answer == storm3 - 1 || answer == storm3 + 1 || answer == vision || answer == cruiserBurst || answer == volcano || answer == oneShot)
            {
                answer = number.Next(30, 70);
            }
            return answer;
        }
        public static int[] Volcano_Capacity_Position(string[,] grid) //Give the position where the volcano is in erupting
        {
            Random number = new Random();
            int[] position = new int[2];
            bool positionQuestion = false;
            while (positionQuestion == false)
            {
                position[0] = number.Next(1, 11);
                position[1] = number.Next(1, 11);
                if (position[0] >= grid.GetLength(0) || position[0] <= 0 || position[1] <= 0 || position[1] >= grid.GetLength(1))
                {
                }
                else
                {
                    if (grid[position[0], position[1]] != "S" && grid[position[0], position[1]] != "W")
                    {
                        positionQuestion = true;
                    }
                }
            }
            return position;
        }
        public static int Capacity_Ship_Length_Since_Position(string[,] grid, int[] position) //Give the length of ships
        {
            int shipLength = 0;
            if (grid[position[0], position[1]] == "A")
            {
                shipLength = 5;
            }
            else if (grid[position[0], position[1]] == "S1")
            {
                shipLength = 3;
            }
            else if (grid[position[0], position[1]] == "S2")
            {
                shipLength = 3;
            }
            else if (grid[position[0], position[1]] == "T")
            {
                shipLength = 2;
            }
            else if (grid[position[0], position[1]] == "C")
            {
                shipLength = 4;
            }
            return shipLength;
        }
        public static string[,] Volcano_Capicity_Delete_Old_Position(string[,] grid, int[] position)
        {
            string name = grid[position[0], position[1]];
            for (int i = 1; i < grid.GetLength(0); i++)
            {
                for (int j = 1; j < grid.GetLength(1); j++)
                {
                    if (grid[i, j] == name)
                    {
                        grid[i, j] = "E";
                    }
                }
            }
            return grid;
        }

        public static string[,] Volcano_Capicity_Add_New_Position_Ship(string[,] grid, int[] position, string name)
        {
            if (position[0] < position[2])
            {
                for (int i = position[0]; i <= position[2]; i++)
                {
                    for (int j = position[1]; j <= position[3]; j++)
                    {
                        grid[i, j] = name;
                    }
                }
            }
            else if (position[0] > position[2])
            {
                for (int i = position[2]; i <= position[0]; i++)
                {
                    for (int j = position[1]; j <= position[3]; j++)
                    {
                        grid[i, j] = name;
                    }
                }
            }
            else if (position[1] < position[3])
            {
                for (int i = position[0]; i <= position[2]; i++)
                {
                    for (int j = position[1]; j <= position[3]; j++)
                    {
                        grid[i, j] = name;
                    }
                }
            }
            else
            {
                for (int i = position[0]; i <= position[2]; i++)
                {
                    for (int j = position[3]; j <= position[1]; j++)
                    {
                        grid[i, j] = name;
                    }
                }
            }
            return grid;
        }
        public static string[,] Volcano_Capacity_Deplacement(string[,] grid)//Function which apply the volcano capacity
        {
            Random number = new Random();
            int[] oldPosition = new int[2];
            oldPosition = Special_Capacity.Volcano_Capacity_Position(grid);
            int shipLength = Special_Capacity.Capacity_Ship_Length_Since_Position(grid, oldPosition);
            int[] newPosition = new int[4];
            string name = grid[oldPosition[0], oldPosition[1]];
            Console.Write("");
            Console.BackgroundColor = ConsoleColor.Black;
            if (shipLength != 0)
            {
                grid = Special_Capacity.Volcano_Capicity_Delete_Old_Position(grid, oldPosition);
                bool start_game = true;
                bool position_question = false;
                while (position_question == false)
                {
                    newPosition[0] = number.Next(1, 11);
                    newPosition[1] = number.Next(1, 11);
                    newPosition[2] = number.Next(1, 11);
                    newPosition[3] = number.Next(1, 11);

                    position_question = Placement.Verification_Enter_Coordinate_User(newPosition, shipLength, grid, start_game);
                }
                grid = Volcano_Capicity_Add_New_Position_Ship(grid, newPosition, name);
            }
            return grid;
        }
        public static string Ship_Resurrection(string[,] grid)//Return the ship which will be ressurected
        {
            string answer = "";
            bool A = false;
            bool T = false;
            bool C = false;
            bool S1 = false;
            bool S2 = false;
            for (int i = 1; i < grid.GetLength(0); i++)
            {
                for (int j = 1; j < grid.GetLength(1); j++)
                {
                    if (grid[i, j] == "A")
                    {
                        A = true;
                    }
                    if (grid[i, j] == "T")
                    {
                        T = true;
                    }
                    if (grid[i, j] == "C")
                    {
                        C = true;
                    }
                    if (grid[i, j] == "S1")
                    {
                        S1 = true;
                    }
                    if (grid[i, j] == "S2")
                    {
                        S2 = true;
                    }
                }
            }

            if (T == false)
            {
                answer = "T";
            }
            else if (S1 == false)
            {
                answer = "S1";
            }
            else if (S2 == false)
            {
                answer = "S2";
            }
            else if (C == false)
            {
                answer = "C";
            }
            else if (A == false)
            {
                answer = "A";
            }

            return answer;
        }
        public static int[] Resurrection_OldPosition(string[,] grid, string name)
        {
            Random number = new Random();
            int[] position = new int[2];
            for (int i = 1; i < grid.GetLength(0); i++)
            {
                for (int j = 1; j < grid.GetLength(1); j++)
                {
                    if (grid[i, j] == name)
                    {
                        position[0] = i;
                        position[1] = j;
                    }
                }
            }
            return position;
        }
        public static int Capacity_Ship_Length_Since_Name(string[,] grid, string name)
        {
            int shipLength = 0;
            if (name == "A")
            {
                shipLength = 5;
            }
            else if (name == "S1")
            {
                shipLength = 3;
            }
            else if (name == "S2")
            {
                shipLength = 3;
            }
            else if (name == "T")
            {
                shipLength = 2;
            }
            else if (name == "C")
            {
                shipLength = 4;
            }
            return shipLength;
        }
        public static string[,] Resurrection_Capicity_Add_New_Position_Ship(string[,] grid, int[] position, string name)
        {
            if (position[0] < position[2])
            {
                for (int i = position[0]; i <= position[2]; i++)
                {
                    for (int j = position[1]; j <= position[3]; j++)
                    {
                        grid[i, j] = name;
                    }
                }
            }
            else if (position[0] > position[2])
            {
                for (int i = position[2]; i <= position[0]; i++)
                {
                    for (int j = position[1]; j <= position[3]; j++)
                    {
                        grid[i, j] = name;
                    }
                }
            }
            else if (position[1] < position[3])
            {
                for (int i = position[0]; i <= position[2]; i++)
                {
                    for (int j = position[1]; j <= position[3]; j++)
                    {
                        grid[i, j] = name;
                    }
                }
            }
            else
            {
                for (int i = position[0]; i <= position[2]; i++)
                {
                    for (int j = position[3]; j <= position[1]; j++)
                    {
                        grid[i, j] = name;
                    }
                }
            }
            return grid;
        }
        public static string[,] Resurrection_Capacity_Deplacement(string[,] grid, string name)//Function which apply Ressurection Capacity
        {
            if (name != "")
            {
                Random number = new Random();
                int shipLength = Capacity_Ship_Length_Since_Name(grid, name);
                int[] newPosition = new int[4];
                if (shipLength != 0)
                {
                    bool start_game = true;
                    bool position_question = false;
                    while (position_question == false)
                    {
                        newPosition[0] = number.Next(1, 11);
                        newPosition[1] = number.Next(1, 11);
                        newPosition[2] = number.Next(1, 11);
                        newPosition[3] = number.Next(1, 11);
                        position_question = Placement.Verification_Enter_Coordinate_User(newPosition, shipLength, grid, start_game);
                    }
                    grid = Special_Capacity.Resurrection_Capicity_Add_New_Position_Ship(grid, newPosition, name);
                }
            }
            return grid;
        }
        public static int Vision(string[,] grid)//Give the column where the player will have the vision
        {
            int column;
            Random number = new Random();
            column = number.Next(1, 11);
            return column;
        }
        public static int Vision_Number_Of_Ship(string[,] grid, int column)//Give the number of ennemy's ship in the column selected
        {
            int numberOfShip = 0;
            bool A = false;
            bool T = false;
            bool C = false;
            bool S1 = false;
            bool S2 = false;
            for (int i = 1; i < grid.GetLength(0); i++)
            {
                if (grid[i, column] == "A" && A == false)
                {
                    numberOfShip++;
                    A = true;
                }
                else if (grid[i, column] == "T" && T == false)
                {
                    numberOfShip++;
                    T = true;
                }
                else if (grid[i, column] == "C" && C == false)
                {
                    numberOfShip++;
                    C = true;
                }
                else if (grid[i, column] == "S1" && S1 == false)
                {
                    numberOfShip++;
                    S1 = true;
                }
                else if (grid[i, column] == "S2" && S2 == false)
                {
                    numberOfShip++;
                    S2 = true;
                }
            }
            return numberOfShip;
        }
        public static string[,] Capicity_Delete_Old_Ship(string[,] grid, string name)
        {
            for (int i = 1; i < grid.GetLength(0); i++)
            {
                for (int j = 1; j < grid.GetLength(1); j++)
                {
                    if (grid[i, j] == name)
                    {
                        grid[i, j] = "S";
                    }
                }
            }
            return grid;
        }
    }
}
