﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet_CSharp_BattleShip
{
    class Placement
    {
        string[] aircraft_carrier;
        string[] cruiser;
        string[] submarine1;
        string[] submarine2;
        string[] torpedo_boat;
        public Placement(string[] aircraft_carrier, string[] cruiser, string[] submarine1, string[] submarine2, string[] torpedo_boat)
        {
            this.aircraft_carrier = aircraft_carrier;
            this.cruiser = cruiser;
            this.submarine1 = submarine1;
            this.submarine2 = submarine2;
            this.torpedo_boat = torpedo_boat;
        }
        public static string[,] Placement_Ship(string[,] grid, string[] ship, int[] position) //Placed a ship on the grid with his position
        {
            int counter = 0;
            if (position[0] == position[2])
            {
                if (position[1] < position[3])
                {
                    for (int i = position[1]; i <= position[3]; i++)
                    {
                        grid[position[0], i] = ship[counter];
                    }
                }
                else
                {
                    for (int i = position[3]; i <= position[1]; i++)
                    {
                        grid[position[0], i] = ship[counter];
                    }
                }
            }
            if (position[1] == position[3])
            {
                if (position[0] < position[2])
                {
                    for (int i = position[0]; i <= position[2]; i++)
                    {
                        grid[i, position[1]] = ship[counter];
                    }
                }
                else
                {
                    for (int i = position[2]; i <= position[0]; i++)
                    {
                        grid[i, position[1]] = ship[counter];
                    }
                }
            }
            return grid;
        }
        public static bool Verification_Ship_In_Grid(string[,] grid, int[] position, bool start_game) // Verify if the ship's position is in valid (in the grid measurements)
        {
            bool answer = true;
            if (start_game == true)
            {
                if (position[0] == position[2])
                {
                    if (position[0] <= 0 || position[0] >= grid.GetLength(0))
                    {
                        answer = false;
                    }
                    if (position[1] <= 0 || position[3] <= 0)
                    {
                        answer = false;
                    }
                    if (position[1] >= grid.GetLength(1) || position[3] >= grid.GetLength(1))
                    {
                        answer = false;
                    }
                }
                if (position[1] == position[3])
                {
                    if (position[1] <= 0 || position[1] >= grid.GetLength(1))
                    {
                        answer = false;
                    }
                    if (position[0] <= 0 || position[2] <= 0)
                    {
                        answer = false;
                    }
                    if (position[0] >= grid.GetLength(0) || position[2] >= grid.GetLength(0))
                    {
                        answer = false;
                    }
                }
            }
            else
            {
                if (position[0] <= 0 || position[0] >= grid.GetLength(0))
                {
                    answer = false;
                }
                if (position[1] <= 0 || position[1] >= grid.GetLength(1))
                {
                    answer = false;
                }
            }
            return answer;
        }
        public static bool Verification_Ship_Present_In_Grid(string[,] grid, int[] position)//Verify if there is a ship on the grid with the position of the ship wanted
        {
            bool answer = true;
            if (position[0] == position[2])
            {
                if (position[1] < position[3])
                {
                    for (int i = position[1]; i <= position[3]; i++)
                    {
                        if (grid[position[0], i] != "E")
                        {
                            answer = false;
                        }
                    }
                }
                else
                {
                    for (int i = position[3]; i <= position[1]; i++)
                    {
                        if (grid[position[0], i] != "E")
                        {
                            answer = false;
                        }
                    }
                }
            }
            if (position[1] == position[3])
            {
                if (position[0] < position[2])
                {
                    for (int i = position[0]; i <= position[2]; i++)
                    {
                        if (grid[i, position[1]] != "E")
                        {
                            answer = false;
                        }
                    }
                }
                else
                {
                    for (int i = position[2]; i <= position[0]; i++)
                    {
                        if (grid[i, position[1]] != "E")
                        {
                            answer = false;
                        }
                    }
                }

            }
            return answer;
        }
        public static int[] Enter_Coordinate_User(string[,] grid)//Verify if the coordinate of the position wanted is available in the game
        {
            int[] position = new int[2];
            string coordinate_User = "";
            bool coordinate_valid = false;
            bool coordinate_long = false;
            string waste_value;

            while (coordinate_valid == false)
            {
                coordinate_User = Console.ReadLine().ToUpper();
                if (coordinate_User.Length == 3)
                {
                    if (coordinate_User[1] == '1' && coordinate_User[2] == '0')
                    {
                        coordinate_valid = true;
                        coordinate_long = true;
                    }
                    else
                    {
                        Announcement.Error_Coordinate();
                    }
                }
                else if (coordinate_User.Length == 2)
                {
                    coordinate_valid = true;
                }
                else
                {
                    Announcement.Error_Coordinate();
                }
            }
            position[0] = Game_Grid.Convert_Letter_To_Number(Convert.ToString(coordinate_User[0]));
            if (coordinate_long == false)
            {
                waste_value = Convert.ToString(coordinate_User[1]);
                if (Game_Grid.Verification_Coordinates(waste_value) == true)
                {
                    position[1] = Convert.ToInt32(waste_value);
                }
            }
            else
            {
                waste_value = Convert.ToString(coordinate_User[1]);
                waste_value += Convert.ToString(coordinate_User[2]);
                if (Game_Grid.Verification_Coordinates(waste_value) == true)
                {
                    position[1] = Convert.ToInt32(waste_value);
                }
            }
            return position;
        }
        public static bool Verification_Enter_Coordinate_User(int[] position, int ship_length, string[,] grid, bool start_game)//Verify if the coordinate of the position wanted is available in the grid
        {
            bool answer = false;
            bool answer_grid = false;
            bool answer_ship = false;
            answer_grid = Placement.Verification_Ship_In_Grid(grid, position, start_game);
            if (answer_grid == true)
            {
                if (start_game == true)
                {
                    answer_ship = Placement.Verification_Ship_Present_In_Grid(grid, position);
                    if (answer_ship == true)
                    {
                        answer = Ship.Verification_Length_Ship(position, ship_length);
                    }
                    else
                    {
                        answer = false;
                    }
                }
                else
                {
                    answer = true;
                }
            }
            else
            {
                answer = false;
            }
            return answer;
        }
    }
}
