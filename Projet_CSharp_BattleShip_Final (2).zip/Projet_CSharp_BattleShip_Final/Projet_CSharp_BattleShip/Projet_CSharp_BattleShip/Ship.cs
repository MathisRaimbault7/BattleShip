﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet_CSharp_BattleShip
{
    class Ship
    {
        int length;
        public Ship(int length)
        {
            this.length = length;
        }
        public static string[] Creation_Ship(string type, int length)
        {
            string[] ship = new string[length];
            for (int i = 0; i < length; i++)
            {
                ship[i] = type;
            }
            return ship;
        }
        public static bool Verification_Length_Ship(int[] position, int length)//Verify if the length ship is respected
        {
            bool answer = true;
            if (position[0] != position[2] && position[1] != position[3])
            {
                answer = false;
            }
            if (position[0] == position[2])
            {
                if (position[1] - position[3] != length - 1 && position[3] - position[1] != length - 1)
                {
                    answer = false;
                }
            }
            if (position[1] == position[3])
            {
                if (position[0] - position[2] != length - 1 && position[2] - position[0] != length - 1)
                {
                    answer = false;
                }
            }
            return answer;
        }
        public static string Torpedo_Boat()
        {
            return "T";
        }
        public static string Submarine1()
        {
            return "S1";
        }
        public static string Submarine2()
        {
            return "S2";
        }
        public static string Cruiser()
        {
            return "C";
        }
        public static string Aircraft()
        {
            return "A";
        }
        public static string Name_Of_Ship(string letter)
        {
            string name = "";
            switch (letter)
            {
                case "A":
                    name = "Aircraft";
                    break;
                case "T":
                    name = "Torpedo Boat";
                    break;
                case "S1":
                    name = "Submarine1";
                    break;
                case "S2":
                    name = "Submarine2";
                    break;
                case "C":
                    name = "Cruiser";
                    break;
                default:
                    break;
            }
            return name;
        }
        public static AI Ship_Touched_By_User(string letter, AI game)// Apply on AI's ship counter the ship touched by player
        {
            int numberOfShipAliveAI = game.Number_Of_Ship_Alive_AI();
            int torpedoAILife = game.Torpedo_AI_Life();
            int submarine1AILife = game.Submarine1_AI_Life();
            int submarine2AILife = game.Submarine2_AI_Life();
            int cruiserAILife = game.Cruiser_AI_Life();
            int aircraftAILife = game.Aicraft_AI_Life();
            switch (letter)
            {
                case "A":
                    aircraftAILife--;
                    break;
                case "T":
                    torpedoAILife--;
                    break;
                case "S1":
                    submarine1AILife--;
                    break;
                case "S2":
                    submarine2AILife--;
                    break;
                case "C":
                    cruiserAILife--;
                    break;
                default:
                    break;
            }
            if (torpedoAILife == 0)
            {
                numberOfShipAliveAI--;
                torpedoAILife--;
            }
            if (submarine1AILife == 0)
            {
                numberOfShipAliveAI--;
                submarine1AILife--;
            }
            if (submarine2AILife == 0)
            {
                numberOfShipAliveAI--;
                submarine2AILife--;
            }
            if (cruiserAILife == 0)
            {
                numberOfShipAliveAI--;
                cruiserAILife--;
            }
            if (aircraftAILife == 0)
            {
                numberOfShipAliveAI--;
                aircraftAILife--;
            }
            game = new AI(numberOfShipAliveAI, torpedoAILife, submarine1AILife, submarine2AILife, cruiserAILife, aircraftAILife);
            return game;
        }
        public static AI Ship_Resurrection_AI(string letter, AI game)// Apply on AI's ship counter the resurection
        {
            int numberOfShipAliveAI = game.Number_Of_Ship_Alive_AI();
            int torpedoAILife = game.Torpedo_AI_Life();
            int submarine1AILife = game.Submarine1_AI_Life();
            int submarine2AILife = game.Submarine2_AI_Life();
            int cruiserAILife = game.Cruiser_AI_Life();
            int aircraftAILife = game.Aicraft_AI_Life();
            switch (letter)
            {
                case "A":
                    aircraftAILife = 5;
                    break;
                case "T":
                    torpedoAILife = 2;
                    break;
                case "S1":
                    submarine1AILife = 3;
                    break;
                case "S2":
                    submarine2AILife = 3;
                    break;
                case "C":
                    cruiserAILife = 4;
                    break;
                default:
                    break;
            }
            game = new AI(numberOfShipAliveAI + 1, torpedoAILife, submarine1AILife, submarine2AILife, cruiserAILife, aircraftAILife);
            return game;
        }
        public static User Ship_Touched_By_AI(string letter, User game)// Apply on player's ship counter the ship touched by AI
        {
            int numberOfShipAliveUser = game.Number_Of_Ship_Alive_User();
            int torpedoUserLife = game.Torpedo_User_Life();
            int submarine1UserLife = game.Submarine1_User_Life();
            int submarine2UserLife = game.Submarine2_User_Life();
            int cruiserUserLife = game.Cruiser_User_Life();
            int aircraftUserLife = game.Aicraft_User_Life();
            switch (letter)
            {
                case "A":
                    aircraftUserLife--;
                    break;
                case "T":
                    torpedoUserLife--;
                    break;
                case "S1":
                    submarine1UserLife--;
                    break;
                case "S2":
                    submarine2UserLife--;
                    break;
                case "C":
                    cruiserUserLife--;
                    break;
                default:
                    break;
            }
            if (torpedoUserLife == 0)
            {
                numberOfShipAliveUser--;
                torpedoUserLife--;
            }
            if (submarine1UserLife == 0)
            {
                numberOfShipAliveUser--;
                submarine1UserLife--;
            }
            if (submarine2UserLife == 0)
            {
                numberOfShipAliveUser--;
                submarine2UserLife--;
            }
            if (cruiserUserLife == 0)
            {
                numberOfShipAliveUser--;
                cruiserUserLife--;
            }
            if (aircraftUserLife == 0)
            {
                numberOfShipAliveUser--;
                aircraftUserLife--;
            }
            game = new User(numberOfShipAliveUser, torpedoUserLife, submarine1UserLife, submarine2UserLife, cruiserUserLife, aircraftUserLife);
            return game;
        }
    }
}
