﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Media;
namespace Projet_CSharp_BattleShip
{
    class Announcement
    {
        public static void Sound(string file)
        {
            SoundPlayer sound = new SoundPlayer(file+".wav");
            sound.Play();
        }
        public static void Start_Announce()
        {
            Console.WriteLine("Hello, what is your name ?");
            string name = Console.ReadLine();
            Thread.Sleep(1000);
            Console.Clear();
            Console.Write("Hi " + name + "! We are going to start playing the game of battleship.");
            Console.WriteLine(" I hope you know the rules!");
            Console.Write("You will be playing against an AI.");
            Console.WriteLine(" The AI has already placed its ships, it's your turn!");
            Console.WriteLine();
        }
        public static void Position_Of_Ship_First(string type, int length)
        {
            Console.WriteLine("You need to position your " + type + ". It does " + length + " squares in length.");
            Console.WriteLine("Enter the letter and number corresponding to the y-axis and x-axis of the box at one end of your " + type + " that you wish to place.");
        }
        public static void Position_Of_Ship_Last(string type)
        {
            Console.WriteLine("Enter the letter and number corresponding to the y-axis and x-axis of the box at the opposite end of your " + type + " that you wish to place.");
        }
        public static void Position_Ship_Wrong_Placed(string type)
        {
            Console.WriteLine("Please make sure you follow the instructions to place your " + Ship.Name_Of_Ship(type) + ".");
        }
        public static string IA_Level()
        {
            Console.Write("Now enter the level of the Artificial Intelligence you wish to tackle. Enter ");
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.Write("1 for easy");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Write(", ");
            Console.BackgroundColor = ConsoleColor.Magenta;
            Console.Write("2 for medium");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Write(" and ");
            Console.BackgroundColor = ConsoleColor.DarkRed;
            Console.Write("3 for strong.");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine("");
            Console.BackgroundColor = ConsoleColor.Black;
            string lvl = Console.ReadLine();
            while (lvl != "1" && lvl != "2" && lvl != "3")
            {
                lvl = Console.ReadLine();
            }
            Console.Clear();
            return lvl;
        }
        public static bool Bonus()
        {
            Console.WriteLine("If you want to have bonuses in this game, enter: true. Otherwise enter: false");
            bool answer = false;
            string answerVerif = "";
            do
            {
                answerVerif = Console.ReadLine();
                answerVerif = answerVerif.ToLower();
            } while (answerVerif != "true" && answerVerif != "false");
            answer = Convert.ToBoolean(answerVerif);
            Console.Clear();
            return answer;
        }
        public static bool Malus()
        {
            Console.WriteLine("If you wish to have malus in this game, enter: true. Otherwise enter: false");
            bool answer = false;
            string answerVerif = "";
            do
            {
                answerVerif = Console.ReadLine();
                answerVerif = answerVerif.ToLower();
            } while (answerVerif != "true" && answerVerif != "false");
            answer = Convert.ToBoolean(answerVerif);
            Console.Clear();
            return answer;
        }
        public static void First_Shot()
        {
            Console.Write("The AI lets you start as it is very nice.");
            Console.WriteLine("Enter a square where you want to launch a missile at the opponent's area.");
        }
        public static void Shot_User()
        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine("Enter the letter and number corresponding to the y-axis and x-axis of the box you wish to atomise respectively. ");
            Console.BackgroundColor = ConsoleColor.Black;
        }
        public static void Error_Coordinate()
        {
            Console.WriteLine("There is an error, the coordinates entered are not valid");
        }
        public static void Shot_Successful()
        {
            Console.WriteLine(" Your shot hit an enemy ship!");
        }
        public static void Shot_Unsuccessful()
        {
            Console.WriteLine(" Your shot did not hit an enemy ship...");
        }
        public static void Ship_Sink(string type)
        {
            Console.WriteLine(" You have sunk the " + type + " enemy.");
        }
        public static void Area_And_ScorePlayer(int numberShipUserAlive, int numberShipAIAlive)
        {
            Console.WriteLine(" ");
            Console.Write("                ");
            Console.BackgroundColor = ConsoleColor.DarkMagenta;
            Console.Write(" YOUR ZONE ");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Write("                                             ");
            Console.BackgroundColor = ConsoleColor.DarkMagenta;
            Console.Write(" ZONE ENEMY ");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine(" ");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine(" ");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Write("          ");
            Console.BackgroundColor = ConsoleColor.DarkMagenta;
            Console.Write(" You are left with " + numberShipUserAlive + " ships ");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Write("                          ");
            Console.BackgroundColor = ConsoleColor.DarkMagenta;
            Console.Write(" It remains " + numberShipAIAlive + " ships to the enemy ");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine(" ");
            Console.WriteLine(" ");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine(" ");
            Console.BackgroundColor = ConsoleColor.Black;
        }
        public static void Title_Announce()
        {
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.Write("Announcement: ");
        }
        public static void Storm()
        {
            Console.Write("You couldn't play because of a storm.");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine("");
            Console.BackgroundColor = ConsoleColor.Black;
        }
        public static void Storm2()
        {
            Console.Write("You could not play due to a 2nd storm.");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine("");
            Console.BackgroundColor = ConsoleColor.Black;
        }
        public static void Storm3()
        {
            Console.Write("You could not play due to a 3rd storm.");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine("");
            Console.BackgroundColor = ConsoleColor.Black;
        }
        public static void Volcano()
        {
            Console.Write("Underwater volcanic eruptions have occurred.");
        }
        public static void Volcano_Ship_Not_Fly()
        {
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.Write(" Fortunately, no enemy ships were blown into the air as a result of the underwater volcanic eruption.");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine("");
            Console.BackgroundColor = ConsoleColor.Black;
        }
        public static void Volcano_Ship_Fly()
        {
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.Write(" An enemy ship has been blown into the air by the volcanic eruptions under the sea. It has totally changed its place!");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine("");
            Console.BackgroundColor = ConsoleColor.Black;
        }
        public static void Resurrection()
        {
            Console.Write("Posseidon is fed up with his ocean being polluted! He has just resurrected an enemy ship that had already been sunk.");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine("");
            Console.BackgroundColor = ConsoleColor.Black;
        }
        public static void Vision()
        {
            Console.Write("Your allied submarine has obtained a radar view of a column in the enemy zone.");
        }
        public static void Vision_Result(int column, int numberOfShip)
        {
            Console.Write(" There is " + numberOfShip + " undiscovered ships in the column " + column + " of the enemy zone.");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine("");
            Console.BackgroundColor = ConsoleColor.Black;
        }
        public static void One_Shot()
        {
            Console.Write(" Thanks to your aircraft carrier, in this round you will be able to one-shot any ship with this atomic bomb.");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine("");
            Console.BackgroundColor = ConsoleColor.Black;
        }
        public static void Ship_Sink_One_Shot(string type)
        {
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.Write(" You have completely sunk the " + type + " enemy thanks to the one shot of the aircraft carrier!");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine("");
            Console.BackgroundColor = ConsoleColor.Black;
        }
        public static void Cruiser_Burst()
        {
            Console.Write("The weather has cleared, the capacity of your cruiser can finally be activated.");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine("");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.Write("On this turn you will be able to send a barrage of 3 shots to 3 different locations in the enemy zone.");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine("");
            Console.BackgroundColor = ConsoleColor.Black;
        }

        public static void Cruiser_Burst_Final()
        {
            Title_Announce();
            Console.Write("Let's goooo ! You have done your cruiser's capacity.");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine("");
            Console.BackgroundColor = ConsoleColor.Black;
        }
        public static void Legende()
        {
            Console.BackgroundColor = ConsoleColor.DarkRed;
            Console.Write("B");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Write("= ");
            Console.BackgroundColor = ConsoleColor.DarkRed;
            Console.Write("Bombed");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Write(" by ennemy | ");
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.Write("E");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Write("= ");
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.Write("Empty");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Write("'s area in your grid | ");
            Console.BackgroundColor = ConsoleColor.DarkRed;
            Console.Write("S");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Write("= ");
            Console.BackgroundColor = ConsoleColor.DarkRed;
            Console.Write("Ship");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Write(" atomized by you | ");
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.Write("O");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Write("= ");
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.Write("Ocean");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Write(" ennemy atomized by you \n\n");
            Console.BackgroundColor = ConsoleColor.Black;
        }
    }
}
