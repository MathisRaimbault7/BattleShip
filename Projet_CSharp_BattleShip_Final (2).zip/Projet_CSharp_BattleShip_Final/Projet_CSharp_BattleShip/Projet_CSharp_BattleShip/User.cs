﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet_CSharp_BattleShip
{
    class User
    {
        int numberOfShipAliveUser = 5;
        int torpedoUserLife = 2;
        int submarine1UserLife = 3;
        int submarine2UserLife = 3;
        int cruiserUserLife = 4;
        int aircraftUserLife = 10;
        public User(int numberOfShipAliveUser, int torpedoUserLife, int submarine1UserLife, int submarine2UserLife, int cruiserUserLife, int aircraftUserLife)
        {
            this.numberOfShipAliveUser = numberOfShipAliveUser;
            this.torpedoUserLife = torpedoUserLife;
            this.submarine1UserLife = submarine1UserLife;
            this.submarine2UserLife = submarine2UserLife;
            this.cruiserUserLife = cruiserUserLife;
            this.aircraftUserLife = aircraftUserLife;
        }
        public static int[] Position_Of_User_Ship(int[] position, bool position_question, string type, int ship_length, string[,] grid, bool startGame, bool presentation)//Return the position of ship placed by player
        {
            bool start_game = true;
            int[] firstPosition = new int[2];
            int[] secondPosition = new int[2];
            while (position_question == false)
            {
                Game_Grid.Display(grid, startGame);
                if (presentation == true)
                {
                    Announcement.Sound("Presentation");
                }
                Announcement.Position_Of_Ship_First(Ship.Name_Of_Ship(type), ship_length);
                firstPosition = Placement.Enter_Coordinate_User(grid);

                Announcement.Position_Of_Ship_Last(Ship.Name_Of_Ship(type));
                secondPosition = Placement.Enter_Coordinate_User(grid);

                position[0] = firstPosition[0]; 
                position[1] = firstPosition[1];
                position[2] = secondPosition[0];
                position[3] = secondPosition[1];

                position_question = Placement.Verification_Enter_Coordinate_User(position, ship_length, grid, start_game);

                Console.Clear();
                if (position_question == false)
                {
                    Announcement.Position_Ship_Wrong_Placed(type);
                }
            }
            return position;
        }
        public static string[,] Touched_Area_By_User(string[,] grid, int[] position, string shipTouched)//Return the grid touched by the player
        {
            if (shipTouched != "")
            {
                grid[position[0], position[1]] = "S";
            }
            else
            {
                grid[position[0], position[1]] = "O";
            }
            return grid;
        }
        public static string Ship_Touched_Or_Not_By_User(string[,] grid, int[] position)//Tell if a ship is touched by player
        {
            string ship = "";
            if (grid[position[0], position[1]] != "E")
            {
                ship = grid[position[0], position[1]];
                Announcement.Shot_Successful();
            }
            else
            {
                Announcement.Shot_Unsuccessful();
            }
            return ship;
        }
        public static int[] Position_Of_Area_Touched_By_User(string[,] grid, int ship_length)// Position bombed on grid
        {
            bool position_question = false;
            int[] position = new int[2] { 0, 0 };
            while (position_question == false)
            {
                Announcement.Shot_User();

                bool start_game = false;
                position = Placement.Enter_Coordinate_User(grid);
                position_question = Placement.Verification_Enter_Coordinate_User(position, ship_length, grid, start_game);
                if (grid[position[0], position[1]] == "S" || grid[position[0], position[1]] == "O")
                {
                    position_question = false;
                }
            }
            return position;
        }
        public int Number_Of_Ship_Alive_User()
        {
            return numberOfShipAliveUser;
        }
        public int Torpedo_User_Life()
        {
            return torpedoUserLife;
        }
        public int Submarine1_User_Life()
        {
            return submarine1UserLife;
        }
        public int Submarine2_User_Life()
        {
            return submarine2UserLife;
        }
        public int Cruiser_User_Life()
        {
            return cruiserUserLife;
        }
        public int Aicraft_User_Life()
        {
            return aircraftUserLife;
        }

    }
}
