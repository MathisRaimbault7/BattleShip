﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Media;

namespace Projet_CSharp_BattleShip
{
    class Program
    {
        //By Mathis Raimbault et Clément Rincé
        static void Main(string[] args)
        {
            bool startGame = false;
            bool presentation = true;
            string type;
            string[,] grid = Game_Grid.Grid(10, 10);
            type = Ship.Aircraft();
            string[] air = Ship.Creation_Ship(type, 5);
            type = Ship.Cruiser();
            string[] cr = Ship.Creation_Ship(type, 4);
            type = Ship.Submarine1();
            string[] sub1 = Ship.Creation_Ship(type, 3);
            type = Ship.Submarine2();
            string[] sub2 = Ship.Creation_Ship(type, 3);
            type = Ship.Torpedo_Boat();
            string[] tor = Ship.Creation_Ship(type, 2);
            Placement ships = new Placement(air, cr, sub1, sub2, tor);
            int[] position = new int[4] { 0, 0, 0, 0 };
            bool position_question = false;
            Announcement.Start_Announce();

            //Position Aircraft on User grid
            type = Ship.Aircraft();
            int ship_length = air.Length;
            position = User.Position_Of_User_Ship(position, position_question, type, ship_length, grid, startGame, presentation);
            grid = Placement.Placement_Ship(grid, air, position);


            presentation = false;
            //Position Torpedo on User grid
            type = Ship.Torpedo_Boat();
            ship_length = tor.Length;
            position = User.Position_Of_User_Ship(position, position_question, type, ship_length, grid, startGame, presentation);
            grid = Placement.Placement_Ship(grid, tor, position);

            //Position Submarine1 on User grid
            type = Ship.Submarine1();
            ship_length = sub1.Length;
            position = User.Position_Of_User_Ship(position, position_question, type, ship_length, grid, startGame, presentation);
            grid = Placement.Placement_Ship(grid, sub1, position);

            //Position Submarine2 on User grid
            type = Ship.Submarine2();
            ship_length = sub2.Length;
            position = User.Position_Of_User_Ship(position, position_question, type, ship_length, grid, startGame, presentation);
            grid = Placement.Placement_Ship(grid, sub2, position);

            //Position Cruiser on User grid
            type = Ship.Cruiser();
            ship_length = cr.Length;
            position = User.Position_Of_User_Ship(position, position_question, type, ship_length, grid, startGame, presentation);
            grid = Placement.Placement_Ship(grid, cr, position);
            Game_Grid.Display(grid, startGame);


            //Positionnement Ship IA
            string[,] grid2 = Game_Grid.Grid(10, 10);
            string type2 = Ship.Aircraft();
            string[] air2 = Ship.Creation_Ship(type2, 5);
            type2 = Ship.Cruiser();
            string[] cr2 = Ship.Creation_Ship(type2, 4);
            type2 = Ship.Submarine1();
            string[] sub3 = Ship.Creation_Ship(type2, 3);
            type2 = Ship.Submarine2();
            string[] sub4 = Ship.Creation_Ship(type2, 3);
            type2 = Ship.Torpedo_Boat();
            string[] tor2 = Ship.Creation_Ship(type2, 2);
            Placement ships2 = new Placement(air2, cr2, sub3, sub4, tor2);
            int[] position2 = new int[4] { 0, 0, 0, 0 };
            bool position_question2 = false;

            //Position Aircraft on AI grid
            type2 = Ship.Aircraft();
            int ship_length2 = air2.Length;
            position2 = AI.Position_Of_AI_Ship(position2, position_question2, type2, ship_length2, grid2);
            grid2 = Placement.Placement_Ship(grid2, air2, position2);

            //Position Torpedo on AI grid
            type2 = Ship.Torpedo_Boat();
            ship_length2 = tor2.Length;
            position2 = AI.Position_Of_AI_Ship(position2, position_question2, type2, ship_length2, grid2);
            grid2 = Placement.Placement_Ship(grid2, tor2, position2);

            //Position Submarine1 on AI grid
            type2 = Ship.Submarine1();
            ship_length2 = sub3.Length;
            position2 = AI.Position_Of_AI_Ship(position2, position_question2, type2, ship_length2, grid2);
            grid2 = Placement.Placement_Ship(grid2, sub3, position2);

            //Position Submarine2 on AI grid
            type2 = Ship.Submarine2();
            ship_length2 = sub4.Length;
            position2 = AI.Position_Of_AI_Ship(position2, position_question2, type2, ship_length2, grid2);
            grid2 = Placement.Placement_Ship(grid2, sub4, position2);

            //Position Cruiser on AI grid
            type2 = Ship.Cruiser();
            ship_length2 = cr2.Length;
            position2 = AI.Position_Of_AI_Ship(position2, position_question2, type2, ship_length2, grid2);
            grid2 = Placement.Placement_Ship(grid2, cr2, position2);

            //Start game
            string lvlAI = Announcement.IA_Level();
            bool bonus = Announcement.Bonus();
            bool malus = Announcement.Malus();
            Announcement.First_Shot();

            User game = new User(5, 2, 3, 3, 4, 5);
            AI game2 = new AI(5, 2, 3, 3, 4, 5);
            string shipTouched = "";
            bool find = false;
            int torpedoUserLife = game.Torpedo_User_Life();
            int aircraftUserLife = game.Aicraft_User_Life();
            int cruiserUserLife = game.Cruiser_User_Life();
            int submarine1UserLife = game.Submarine1_User_Life();
            int submarine2UserLife = game.Submarine2_User_Life();
            int numberShipUserAlive = game.Number_Of_Ship_Alive_User();
            int[] positionFind = new int[] { 0, 0 };
            int numberShipAIAlive = game2.Number_Of_Ship_Alive_AI();
            int sensDirection = 0;
            int sens = 0;
            int[] sensGoodWay = new int[] { 0, 0 };
            bool GoodWay = false;
            string shipTouchedMemory = "";
            string[,] megaGridDisplay = new string[(grid.GetLength(0) + grid2.GetLength(0)) / 2, grid.GetLength(1) + grid2.GetLength(1)];
            startGame = true;
            int vision = 0;
            int storm = 0;
            int storm2 = 0;
            int storm3 = 0;
            int oneShot = 0;
            int volcano = 0;
            int cruiserBurst = 0;
            int resurrrection = 0;
            //Assignment of the turn in which the special abilities will take place
            storm = Special_Capacity.Storm_Round(storm2, storm3, vision, cruiserBurst, oneShot, resurrrection, volcano);
            storm2 = Special_Capacity.Storm2_Round(storm, storm3, vision, cruiserBurst, oneShot, resurrrection, volcano);
            storm3 = Special_Capacity.Storm3_Round(storm, storm2, vision, cruiserBurst, oneShot, resurrrection, volcano);
            vision = Special_Capacity.Vision_Round(storm, storm2, storm3, cruiserBurst, oneShot, resurrrection, volcano);
            volcano = Special_Capacity.Volcano_Round(storm, storm2, storm3, vision, cruiserBurst, resurrrection, oneShot);
            oneShot = Special_Capacity.One_Shot_Round(storm, storm2, storm3, vision, cruiserBurst, resurrrection, volcano);
            cruiserBurst = Special_Capacity.Cruiser_Burst_Round(storm, storm2, storm3, vision, oneShot, resurrrection, volcano);
            resurrrection = Special_Capacity.Resurrection_Round(storm, storm2, storm3, vision, cruiserBurst, volcano, oneShot);
            int round = 0;

            //Choice of malus or bonus 
            if (bonus == false)
            {
                vision = -1;
                oneShot = -1;
                cruiserBurst = -1;
            }

            if (malus == false)
            {
                storm = -1;
                storm2 = -1;
                storm3 = -1;
                volcano = -1;
                resurrrection = -1;
            }

            while (game.Number_Of_Ship_Alive_User() > 0 && game2.Number_Of_Ship_Alive_AI() > 0)//The game continue while the number of ship Alive of AI or Player is strictly superior to 0
            {
                if (round == 0)
                {
                    megaGridDisplay = Game_Grid.Construction_MegaGrid(grid, grid2);
                    Game_Grid.Display(megaGridDisplay, startGame);
                    Console.WriteLine();
                }
                round++;
                if (round == vision || round == resurrrection || round == volcano || round == oneShot || round == cruiserBurst || round == storm + 1 || round == storm2 + 1 || round == storm3 + 1)
                {
                    Announcement.Title_Announce();
                }
                if (round == storm + 1)
                {
                    Announcement.Storm();
                    Announcement.Sound("Storm");
                }
                else if (round == storm2 + 1)
                {
                    Announcement.Storm2();
                    Announcement.Sound("Storm");
                }
                else if (round == storm3 + 1)
                {
                    Announcement.Storm3();
                    Announcement.Sound("Storm");
                }

                if (round == vision)
                {
                    int column;
                    Announcement.Vision();
                    column = Special_Capacity.Vision(grid2);
                    int numberOfShip = Special_Capacity.Vision_Number_Of_Ship(grid2, column);
                    Announcement.Vision_Result(column, numberOfShip);
                    Announcement.Sound("Vision");

                }

                if (round == resurrrection)
                {
                    string name = "";
                    name = Special_Capacity.Ship_Resurrection(grid2);
                    if (name != "")
                    {
                        grid2 = Special_Capacity.Resurrection_Capacity_Deplacement(grid2, name);
                        Announcement.Resurrection();
                        Announcement.Sound("Resurrection");
                        game2 = Ship.Ship_Resurrection_AI(name, game2);
                        numberShipAIAlive = game2.Number_Of_Ship_Alive_AI();
                    }
                }

                if (round == volcano)
                {
                    int counter = 0;
                    bool changement = false;
                    Announcement.Volcano();
                    Announcement.Sound("Volcano");
                    do
                    {
                        string[,] gridVerif = new string[11, 11];
                        changement = false;
                        for (int i = 0; i < gridVerif.GetLength(0); i++)
                        {
                            for (int j = 0; j < gridVerif.GetLength(1); j++)
                            {
                                gridVerif[i, j] = grid2[i, j];
                            }
                        }
                        grid2 = Special_Capacity.Volcano_Capacity_Deplacement(grid2);
                        for (int i = 0; i < gridVerif.GetLength(0); i++)
                        {
                            for (int j = 0; j < gridVerif.GetLength(1); j++)
                            {
                                if (gridVerif[i, j] != grid2[i, j])
                                {
                                    changement = true;
                                }
                            }
                        }
                        counter++;
                    } while (counter < 10000 && changement == false);//20 box touched by volcano
                    if (changement == true)
                    {
                        Thread.Sleep(6000);
                        Announcement.Volcano_Ship_Fly();
                        Announcement.Sound("Fly");
                    }
                    else
                    {
                        Thread.Sleep(6000);
                        Announcement.Volcano_Ship_Not_Fly();
                    }
                }

                if (round == oneShot)
                {
                    Announcement.One_Shot();
                    position2 = User.Position_Of_Area_Touched_By_User(grid2, 0);
                    Console.Clear();
                    shipTouched = User.Ship_Touched_Or_Not_By_User(grid2, position2);
                    if (shipTouched != "")
                    {
                        if (round == oneShot)
                        {
                            while (game2.Number_Of_Ship_Alive_AI() >= numberShipAIAlive)
                            {
                                game2 = Ship.Ship_Touched_By_User(shipTouched, game2);
                            }
                        }
                    }
                    else
                    {
                        grid2 = User.Touched_Area_By_User(grid2, position2, shipTouched);
                    }
                    if (numberShipAIAlive != game2.Number_Of_Ship_Alive_AI())
                    {
                        Console.WriteLine("");
                        Announcement.Title_Announce();
                        Announcement.Ship_Sink_One_Shot(Ship.Name_Of_Ship(shipTouched));
                    }
                    Announcement.Sound("OneShot");
                    grid2 = Special_Capacity.Capicity_Delete_Old_Ship(grid2, shipTouched);
                    numberShipAIAlive = game2.Number_Of_Ship_Alive_AI();
                }
                else if (round == cruiserBurst)
                {
                    Announcement.Cruiser_Burst();
                    int numberShot = 3;
                    while (numberShot >= 0)
                    {
                        position2 = User.Position_Of_Area_Touched_By_User(grid2, 0);
                        Console.Clear();
                        shipTouched = User.Ship_Touched_Or_Not_By_User(grid2, position2);
                        if (shipTouched != "")
                        {
                            game2 = Ship.Ship_Touched_By_User(shipTouched, game2);
                        }
                        if (numberShipAIAlive != game2.Number_Of_Ship_Alive_AI())
                        {
                            Announcement.Ship_Sink(Ship.Name_Of_Ship(shipTouched));
                        }
                        grid2 = User.Touched_Area_By_User(grid2, position2, shipTouched);

                        if (numberShot > 0)
                        {
                            megaGridDisplay = Game_Grid.Construction_MegaGrid(grid, grid2);
                            Game_Grid.Display(megaGridDisplay, startGame);
                            Announcement.Area_And_ScorePlayer(numberShipUserAlive, game2.Number_Of_Ship_Alive_AI());
                            if (numberShot == 1)
                            {
                                Announcement.Cruiser_Burst_Final();
                                Announcement.Sound("Cruiser");
                            }
                        }
                        numberShipAIAlive = game2.Number_Of_Ship_Alive_AI();
                        numberShot--;
                    }
                }
                else if (round == storm)
                {
                    Console.Clear();
                }
                else if (round == storm2)
                {
                    Console.Clear(); 
                }
                else if (round == storm3)
                {
                    Console.Clear();
                }
                else //Round for player without special capacities
                {
                    position2 = User.Position_Of_Area_Touched_By_User(grid2, 0);
                    Console.Clear();
                    shipTouched = User.Ship_Touched_Or_Not_By_User(grid2, position2);
                    if (shipTouched != "")
                    {
                        game2 = Ship.Ship_Touched_By_User(shipTouched, game2);
                    }
                    if (numberShipAIAlive != game2.Number_Of_Ship_Alive_AI())
                    {
                        Announcement.Ship_Sink(Ship.Name_Of_Ship(shipTouched));
                    }
                    grid2 = User.Touched_Area_By_User(grid2, position2, shipTouched);
                    numberShipAIAlive = game2.Number_Of_Ship_Alive_AI();
                }
                if (lvlAI == "1")//Easier level of AI
                {
                    position = AI.Position_Of_Area_Touched_By_AI(grid, 0);
                    shipTouched = AI.Ship_Touched_Or_Not_By_AI(grid, position);
                    if (shipTouched != "")
                    {
                        game = Ship.Ship_Touched_By_AI(shipTouched, game);
                    }
                    grid = AI.Touched_Area_By_AI(grid, position);
                    megaGridDisplay = Game_Grid.Construction_MegaGrid(grid, grid2);
                    Game_Grid.Display(megaGridDisplay, startGame);
                    Announcement.Area_And_ScorePlayer(numberShipUserAlive, numberShipAIAlive);

                    if (shipTouched != "")
                    {
                        Announcement.Sound("Touched");
                    }
                    else
                    {
                        Announcement.Sound("DontTouched");
                    }

                    torpedoUserLife = game.Torpedo_User_Life();
                    aircraftUserLife = game.Aicraft_User_Life();
                    cruiserUserLife = game.Cruiser_User_Life();
                    submarine1UserLife = game.Submarine1_User_Life();
                    submarine2UserLife = game.Submarine2_User_Life();
                    numberShipUserAlive = game.Number_Of_Ship_Alive_User();
                }
                else if (lvlAI == "2")//Medium level of AI
                {
                    if (find == false)//the AI follow the classic technical strategy to find a player's ship
                    {
                        position = AI.Position_Of_Area_Touched_By_AI(grid, 0);
                        shipTouched = AI.Ship_Touched_Or_Not_By_AI(grid, position);
                        if (shipTouched != "")
                        {
                            game = Ship.Ship_Touched_By_AI(shipTouched, game);
                        }
                        grid = AI.Touched_Area_By_AI(grid, position);
                        megaGridDisplay = Game_Grid.Construction_MegaGrid(grid, grid2);
                        Game_Grid.Display(megaGridDisplay, startGame);
                        Announcement.Area_And_ScorePlayer(numberShipUserAlive, numberShipAIAlive);

                        if (torpedoUserLife != game.Torpedo_User_Life() || submarine1UserLife != game.Submarine1_User_Life() || submarine2UserLife != game.Submarine2_User_Life() || aircraftUserLife != game.Aicraft_User_Life() || cruiserUserLife != game.Cruiser_User_Life())
                        {
                            find = true;
                            positionFind[0] = position[0];
                            positionFind[1] = position[1];
                        }
                        else
                        {
                            find = false;
                        }
                        if (numberShipUserAlive != game.Number_Of_Ship_Alive_User())
                        {
                            find = false;
                        }

                        if (shipTouched != "")
                        {
                            Announcement.Sound("Touched");
                        }
                        else
                        {
                            Announcement.Sound("DontTouched");
                        }

                        //update lives of each Player's ship
                        torpedoUserLife = game.Torpedo_User_Life();
                        aircraftUserLife = game.Aicraft_User_Life();
                        cruiserUserLife = game.Cruiser_User_Life();
                        submarine1UserLife = game.Submarine1_User_Life();
                        submarine2UserLife = game.Submarine2_User_Life();
                        numberShipUserAlive = game.Number_Of_Ship_Alive_User();
                    }
                    else//the AI try to find the player's ship tracked
                    {
                        int counter = 5;
                        int[] positionBlocked = new int[] { positionFind[0], positionFind[1] };
                        position = AI.Position_Of_Area_Touched_By_AI_Brain(grid, 0, positionBlocked);
                        shipTouched = AI.Ship_Touched_Or_Not_By_AI(grid, position);
                        if (shipTouched != "")
                        {
                            game = Ship.Ship_Touched_By_AI(shipTouched, game);
                            counter--;
                        }
                        grid = AI.Touched_Area_By_AI(grid, position);
                        megaGridDisplay = Game_Grid.Construction_MegaGrid(grid, grid2);
                        Game_Grid.Display(megaGridDisplay, startGame);
                        Announcement.Area_And_ScorePlayer(numberShipUserAlive, numberShipAIAlive);

                        if (counter <= 0 || numberShipUserAlive != game.Number_Of_Ship_Alive_User())
                        {
                            find = false;
                        }
                        else
                        {
                            find = true;
                        }

                        if (shipTouched != "")
                        {
                            Announcement.Sound("Touched");
                        }
                        else
                        {
                            Announcement.Sound("DontTouched");
                        }

                        torpedoUserLife = game.Torpedo_User_Life();
                        aircraftUserLife = game.Aicraft_User_Life();
                        cruiserUserLife = game.Cruiser_User_Life();
                        submarine1UserLife = game.Submarine1_User_Life();
                        submarine2UserLife = game.Submarine2_User_Life();
                        numberShipUserAlive = game.Number_Of_Ship_Alive_User();
                    }
                }
                else if (lvlAI == "3")//highest level of AI 
                {
                    if (find == false)//the AI follow the classic technical strategy to find a player's ship like in lvl 2
                    {
                        position = AI.Position_Of_Area_Touched_By_AI_Smart(grid, 0);
                        shipTouched = AI.Ship_Touched_Or_Not_By_AI(grid, position);
                        shipTouchedMemory = shipTouched;
                        if (shipTouched != "")
                        {
                            game = Ship.Ship_Touched_By_AI(shipTouched, game);
                        }
                        grid = AI.Touched_Area_By_AI(grid, position);
                        megaGridDisplay = Game_Grid.Construction_MegaGrid(grid, grid2);

                        Game_Grid.Display(megaGridDisplay, startGame);
                        Announcement.Area_And_ScorePlayer(numberShipUserAlive, numberShipAIAlive);

                        if (torpedoUserLife != game.Torpedo_User_Life() || submarine1UserLife != game.Submarine1_User_Life() || submarine2UserLife != game.Submarine2_User_Life() || aircraftUserLife != game.Aicraft_User_Life() || cruiserUserLife != game.Cruiser_User_Life())
                        {
                            find = true;
                            positionFind[0] = position[0];
                            positionFind[1] = position[1];
                        }
                        else
                        {
                            find = false;
                        }
                        if (numberShipUserAlive != game.Number_Of_Ship_Alive_User())
                        {
                            find = false;
                        }

                        if (shipTouched != "")
                        {
                            Announcement.Sound("Touched");
                        }
                        else
                        {
                            Announcement.Sound("DontTouched");
                        }

                        torpedoUserLife = game.Torpedo_User_Life();
                        aircraftUserLife = game.Aicraft_User_Life();
                        cruiserUserLife = game.Cruiser_User_Life();
                        submarine1UserLife = game.Submarine1_User_Life();
                        submarine2UserLife = game.Submarine2_User_Life();
                        numberShipUserAlive = game.Number_Of_Ship_Alive_User();

                        sens = 0;
                        sensDirection = 0;
                        GoodWay = false;
                        sensGoodWay[0] = 0;
                        sensGoodWay[1] = 0;
                    }
                    else//the AI tracked the player's ship until sink it
                    {
                        int[] positionBlocked = new int[] { positionFind[0], positionFind[1] };
                        int xBlocked = positionBlocked[0];
                        int yBlocked = positionBlocked[1];
                        if (GoodWay == true)//the AI is on the good way horizontal or vertical to sink the player's ship
                        {
                            position = AI.Position_Of_Area_Touched_By_AI_Big_Brain(grid, 0, position, sensGoodWay[0], sensGoodWay[1], GoodWay);
                        }
                        else
                        {
                            position = AI.Position_Of_Area_Touched_By_AI_Big_Brain(grid, 0, positionBlocked, sens, sensDirection, GoodWay);
                        }
                        int possibility = 0;
                        bool did = false;
                        int[] positionCopy = new int[2];
                        if (position[0] >= grid.GetLength(0) || position[1] >= grid.GetLength(1) || position[0] <= 0 || position[1] <= 0 || grid[position[0], position[1]] == "B")
                        {// this condition loop try to corrected any errors of the AI big brain function
                            did = true;
                            int indexer = 1;
                            positionCopy[0] = position[0];
                            positionCopy[1] = position[1];
                            while (positionCopy[0] >= grid.GetLength(0) || positionCopy[1] >= grid.GetLength(1) || positionCopy[0] <= 0 || positionCopy[1] <= 0 || grid[positionCopy[0], positionCopy[1]] == "B")
                            {
                                possibility++;
                                if (possibility == 1)
                                {
                                    positionCopy[1] += indexer;
                                }
                                else if (possibility == 2)
                                {
                                    positionCopy[1] -= indexer;
                                    positionCopy[1] -= indexer;
                                }
                                else if (possibility == 3)
                                {
                                    positionCopy[1] += indexer;
                                    positionCopy[0] += indexer;
                                }
                                else
                                {
                                    positionCopy[0] -= indexer;
                                    positionCopy[0] -= indexer;
                                    indexer++;
                                    possibility = 0;
                                }
                            }
                        }
                        else
                        {
                            shipTouched = AI.Ship_Touched_Or_Not_By_AI(grid, position);
                            if (shipTouched == shipTouchedMemory || shipTouched == "")//AI look if the box touched is the same as the previous touched or if the box touched don't contained a player's ship
                            {
                                if (shipTouched != "" && GoodWay == false)//if AI don't touched a player's ship and it's not on the good way
                                {
                                    game = Ship.Ship_Touched_By_AI(shipTouched, game);
                                    sensGoodWay = Game_Grid.Sens_Good_Way(position, xBlocked, yBlocked);
                                    GoodWay = true;
                                }
                                else if (shipTouched != "")//if AI don't touched a player's ship 
                                {
                                    game = Ship.Ship_Touched_By_AI(shipTouched, game);
                                    GoodWay = true;
                                }
                                else if (GoodWay == true)//if AI is on the good way
                                {
                                    sensGoodWay[0] *= -1;
                                    sensGoodWay[1] *= -1;
                                    GoodWay = true;
                                }
                                else
                                {
                                    GoodWay = false;
                                }
                            }
                            else
                            {
                                if (shipTouched != shipTouchedMemory)//if the box touched is different than the previous one
                                {
                                    game = Ship.Ship_Touched_By_AI(shipTouched, game);
                                    GoodWay = false;
                                }
                                else if (GoodWay == true)//If the AI is on the good way to sink the player's ship
                                {
                                    sensGoodWay[0] *= -1;
                                    sensGoodWay[1] *= -1;
                                    GoodWay = true;
                                }
                                else
                                {
                                    GoodWay = false;
                                }
                            }
                        }

                        if (did == true)//if the position of the box wanted by AI was an error
                        {
                            shipTouched = AI.Ship_Touched_Or_Not_By_AI(grid, positionCopy);
                            if (shipTouched != "")
                            {
                                game = Ship.Ship_Touched_By_AI(shipTouched, game);
                            }
                            grid = AI.Touched_Area_By_AI(grid, positionCopy);
                        }
                        else
                        {
                            grid = AI.Touched_Area_By_AI(grid, position);
                        }

                        //Display the two grid Game
                        megaGridDisplay = Game_Grid.Construction_MegaGrid(grid, grid2);

                        Game_Grid.Display(megaGridDisplay, startGame);
                        Console.WriteLine();
                        Announcement.Area_And_ScorePlayer(game.Number_Of_Ship_Alive_User(), numberShipAIAlive);

                        if (numberShipUserAlive > game.Number_Of_Ship_Alive_User())//if the player's ship is sink, the AI is looking for another player's ship
                        {
                            find = false;
                        }
                        else
                        {
                            find = true;
                        }

                        if(shipTouched!="")
                        {
                            Announcement.Sound("Touched");
                        }
                        else
                        {
                            Announcement.Sound("DontTouched");
                        }

                        torpedoUserLife = game.Torpedo_User_Life();
                        aircraftUserLife = game.Aicraft_User_Life();
                        cruiserUserLife = game.Cruiser_User_Life();
                        submarine1UserLife = game.Submarine1_User_Life();
                        submarine2UserLife = game.Submarine2_User_Life();
                        numberShipUserAlive = game.Number_Of_Ship_Alive_User();
                    }
                }

            }
            Console.WriteLine("\nSuspense.....\n\n");
            Thread.Sleep(2000);
            //end game, tell the result of the game
            if (game.Number_Of_Ship_Alive_User() == 0)
            {
                Console.BackgroundColor = ConsoleColor.Red;
                Console.Write("You lose...");
                Console.BackgroundColor = ConsoleColor.Black;
                Console.WriteLine("");
                Announcement.Sound("Lose");
            }
            else
            {
                Console.BackgroundColor = ConsoleColor.Red;
                Console.Write("You win !! The AI congratulates you !");
                Console.BackgroundColor = ConsoleColor.Black;
                Console.WriteLine("");
                Announcement.Sound("Win");
            }
            Console.ReadKey();
        }
    }
}
