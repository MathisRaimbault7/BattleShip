﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet_CSharp_BattleShip
{
    class Game_Grid
    {
        int row = 10;
        int column = 10;
        string[,] grid;
        public Game_Grid(int row, int column, string[,] grid)
        {
            this.row = row;
            this.column = column;
            this.grid = grid;
        }
        public static string[,] Grid(int row, int column) //Create a grid with all box empty
        {
            string[,] grid = new string[row + 1, column + 1];
            for (int i = 0; i < grid.GetLength(0); i++)
            {
                for (int j = 0; j < grid.GetLength(1); j++)
                {
                    grid[i, j] = "E";
                }
            }
            grid[0, 0] = null;
            for (int i = 1; i < grid.GetLength(1); i++)
            {
                grid[0, i] = Convert.ToString(i);
            }
            for (int i = 1; i < grid.GetLength(0); i++)
            {
                grid[i, 0] = Convert.ToString(i);
            }
            return grid;
        }
        public static void Display(string[,] grid, bool startGame)//Display grid with colors
        {
            Console.WriteLine("");
            for (int i = 0; i < grid.GetLength(0); i++)
            {
                for (int j = 0; j < grid.GetLength(1); j++)
                {
                    if (j == grid.GetLength(1) / 2 && startGame == true)
                    {
                        Console.Write("            ");
                    }
                    if (grid[i, j] == "1" || grid[i, j] == "2" || grid[i, j] == "3" || grid[i, j] == "4" || grid[i, j] == "5" || grid[i, j] == "6" || grid[i, j] == "7" || grid[i, j] == "8" || grid[i, j] == "9" || grid[i, j] == "10")
                    {
                        if (grid[0, j] == "10")
                        {
                            Console.BackgroundColor = ConsoleColor.DarkMagenta;
                            Console.Write("|" + grid[i, j] + " ");
                            Console.BackgroundColor = ConsoleColor.Black;
                        }
                        else if (grid[i, j] == null)
                        {
                            Console.Write("    ");

                        }
                        else if (j == 0 || (j == grid.GetLength(1) / 2 && startGame == true))
                        {
                            Console.BackgroundColor = ConsoleColor.DarkMagenta;
                            Console.Write("| " + Game_Grid.Convert_Number_To_Letter(Convert.ToInt32(grid[i, j])) + " ");
                            Console.BackgroundColor = ConsoleColor.Black;
                        }
                        else
                        {
                            Console.BackgroundColor = ConsoleColor.DarkMagenta;
                            Console.Write("| " + grid[i, j] + " ");
                            Console.BackgroundColor = ConsoleColor.Black;
                        }
                    }
                    else if (grid[i, j] == "S1" || grid[i, j] == "A" || grid[i, j] == "T" || grid[i, j] == "C" || grid[i, j] == "S2")
                    {
                        if (j >= grid.GetLength(1) / 2 && startGame == true)
                        {
                            Console.BackgroundColor = ConsoleColor.DarkYellow;
                            Console.Write("| ? ");
                            Console.BackgroundColor = ConsoleColor.Black;
                        }
                        else if (grid[i, j] != "S1" && grid[i, j] != "S2")
                        {
                            Console.BackgroundColor = ConsoleColor.DarkGray;
                            Console.Write("| " + grid[i, j] + " ");
                            Console.BackgroundColor = ConsoleColor.Black;
                        }
                        else
                        {
                            Console.BackgroundColor = ConsoleColor.DarkGray;
                            Console.Write("|" + grid[i, j] + " ");
                            Console.BackgroundColor = ConsoleColor.Black;
                        }
                    }
                    else if (grid[i, j] == "B")
                    {
                        if (grid[i, j] == "10")
                        {
                            Console.BackgroundColor = ConsoleColor.DarkRed;
                            Console.Write("|" + grid[i, j] + " ");
                            Console.BackgroundColor = ConsoleColor.Black;
                        }
                        else if (grid[i, j] == null)
                        {
                            Console.Write("    ");
                        }
                        else
                        {
                            Console.BackgroundColor = ConsoleColor.DarkRed;
                            Console.Write("| " + grid[i, j] + " ");
                            Console.BackgroundColor = ConsoleColor.Black;
                        }
                    }
                    else if (grid[i, j] == "S")
                    {
                        Console.BackgroundColor = ConsoleColor.DarkRed;
                        Console.Write("| " + grid[i, j] + " ");
                        Console.BackgroundColor = ConsoleColor.Black;
                    }
                    else if (grid[i, j] == "O")
                    {
                        Console.BackgroundColor = ConsoleColor.DarkCyan;
                        Console.Write("| " + grid[i, j] + " ");
                        Console.BackgroundColor = ConsoleColor.Black;
                    }
                    else
                    {
                        if (grid[i, j] == null)
                        {
                            Console.Write("    ");
                        }
                        else if (j >= grid.GetLength(1) / 2 && startGame == true)
                        {
                            Console.BackgroundColor = ConsoleColor.DarkYellow;
                            Console.Write("| ? ");
                            Console.BackgroundColor = ConsoleColor.Black;
                        }
                        else
                        {
                            Console.BackgroundColor = ConsoleColor.DarkCyan;
                            Console.Write("| " + grid[i, j] + " ");
                            Console.BackgroundColor = ConsoleColor.Black;
                        }
                    }
                }
                if (i == grid.GetLength(0) - 1)
                {
                    Console.WriteLine("\n");
                }
                else
                {
                    Console.WriteLine("\n");
                }
            }
            Announcement.Legende();
        }
        public static int Convert_Letter_To_Number(string letter)//Convert letter to number for the position enter by player
        {
            int number = 0;
            switch (letter)
            {
                case "A":
                    number = 1;
                    break;
                case "B":
                    number = 2;
                    break;
                case "C":
                    number = 3;
                    break;
                case "D":
                    number = 4;
                    break;
                case "E":
                    number = 5;
                    break;
                case "F":
                    number = 6;
                    break;
                case "G":
                    number = 7;
                    break;
                case "H":
                    number = 8;
                    break;
                case "I":
                    number = 9;
                    break;
                case "J":
                    number = 10;
                    break;
                default:
                    break;
            }
            return number;
        }

        public static char Convert_Number_To_Letter(int number)//Convert number to letter for the display of the grid
        {
            char letter = 'A';
            switch (number)
            {
                case 1:
                    letter = 'A';
                    break;
                case 2:
                    letter = 'B';
                    break;
                case 3:
                    letter = 'C';
                    break;
                case 4:
                    letter = 'D';
                    break;
                case 5:
                    letter = 'E';
                    break;
                case 6:
                    letter = 'F';
                    break;
                case 7:
                    letter = 'G';
                    break;
                case 8:
                    letter = 'H';
                    break;
                case 9:
                    letter = 'I';
                    break;
                case 10:
                    letter = 'J';
                    break;
                default:
                    break;
            }
            return letter;
        }

        public static bool Verification_Coordinates(string value)
        {
            bool answer = false;
            if (value == "1" || value == "2" || value == "3" || value == "4" || value == "5" || value == "6" || value == "7" || value == "8" || value == "9" || value == "10")
            {
                answer = true;
            }
            return answer;
        }

        public static int[,] Construction_Grid_Smart()//Create the classic thechnical strategy in grid for AI. That's permitted to have the position of shot to touch minimum one time each ship of player
        {
            int[,] grid_Smart = new int[11, 11];
            int pair = 0;
            for (int i = 1; i < 11; i++)
            {
                if (pair % 2 == 0)
                {
                    for (int j = 1; j < 11; j = j + 2)
                    {
                        grid_Smart[i, j] = 1;
                    }
                }
                else
                {
                    for (int j = 2; j < 11; j = j + 2)
                    {
                        grid_Smart[i, j] = 1;
                    }
                }
                pair++;
            }
            return grid_Smart;
        }

        public static bool Verification_Smart_Grid_Empty(int[,] grid)
        {
            bool answer = true;
            for (int i = 1; i < 11; i++)
            {
                for (int j = 1; j < 11; j++)
                {
                    if (grid[i, j] == 1)
                    {
                        answer = false;
                    }
                }
            }
            return answer;
        }

        public static int[] Sens_Good_Way(int[] position, int x, int y)
        {
            int[] sens = new int[2];
            sens[0] = position[0] - x;
            sens[1] = position[1] - y;
            return sens;
        }

        public static string[,] Construction_MegaGrid(string[,] grid, string[,] grid2)//Create a double grid for the display of the game
        {
            string[,] megaGridDisplay = new string[(grid.GetLength(0) + grid2.GetLength(0)) / 2, grid.GetLength(1) + grid2.GetLength(1)];
            for (int i = 0; i < megaGridDisplay.GetLength(0); i++)
            {
                for (int j = 0; j < megaGridDisplay.GetLength(1); j++)
                {
                    if (j >= grid.GetLength(1))
                    {
                        megaGridDisplay[i, j] = grid2[i, j - grid.GetLength(1)];
                    }
                    else
                    {
                        megaGridDisplay[i, j] = grid[i, j];
                    }
                }
            }
            return megaGridDisplay;
        }
    }
}
